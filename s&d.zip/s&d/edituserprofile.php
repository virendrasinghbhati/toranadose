<?php
session_start();
 include('connection.php');?>
<?php error_reporting(0);?>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="js/bootstrap.min.js"/>
<script src="js/jquery-1.11.1.js"/></script>
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<div class="container">
<div class="row">
<div class="col-md-12">
<legend>Please Edit Your Profile</legend>
</div></div>
<div class="row">
<div class="col-md-12 aa">
<div class="nav">
<ul class="nav nav-justified">
<li><a href="home.php"> HOME </a></li>
<li  class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> PROFILE </a>
<ul class="dropdown-menu">
  <li><a href="orgpro.php">ORGANISATION PROFILE</a></li>
  <li><a href="userprofile.php">USER PROFILE</a></li>
</ul>
</li>
<li><a href="organisationreg.php">ORG. REGISTRATION</a></li>
<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> CONTACT US</a>
    <ul class="dropdown-menu">
    <li>Call us-8696238996 </li>
    <li><a href="">virubana9@gmail.com</a></li>
    <li><a href="">erbhati93@gmail.com</a></li>
    </ul>
</li>
</ul></div></div>
<div class="col-md-3"></div>
<div class="col-md-6">
<fieldset>
<form action="" method="post" enctype="multipart/form-data"/>
<?php 
     $emailid=$_SESSION['email'];
	 $sql=mysql_query(" select * from `userreg` where emailid='".$emailid."'");
     while($row=mysql_fetch_array($sql))
	 {
		 ?>
		 <label for="">FULL NAME :</label>
         <input type="text" name="fnm" value="<?php echo $row['name'];?>" class="form-control"/>
         <label for="">DATE OF BIRTH :</label> 
         <input type="date" name="dt" value="<?php echo $row['dob'];?>" class="form-control"/>        
         <label for="">CONTACT NO. :</label>
         <input type="number" name="phone" value="<?php echo $row['cnt'];?>" class="form-control"/>
          <label for="">ALTERNATE CONTACT NO. :</label>
         <input type="number" name="aphone" value="<?php echo $row['acnt'];?>" class="form-control"/>
         <label for="">ADDRESS :</label>
		 <input type="text" name="adrs" value="<?php echo $row['address'];?>" class="form-control"/>
         <label for="">Your Picture</label>
         <input type="file" name="img" class="form-control"/>
         <?php echo $row['p_img'];?>
         <img src="<?php echo $row['img'];?>" width="10%"/><br>
         <input type="submit" name="update" value="UPDATE"/>
         </form>
         </fieldset>
		 <?php
		 }
         ?>
         </div> <div class="col-md-3"></div> </div></div>
		 <?php
           if(isset($_POST['update']))
		    {
			  $name=$_FILES['img']['name'];
	          $type=$_FILES['img']['type'];
	          $size=($_FILES['img']['size'])/1024;
  // echo $name;
  // echo $type;
   //echo $size;
$ext=end(explode('.',$name));
if (($ext == "gif")
|| ($ext == "jpeg")
|| ($ext == "jpg")
|| ($ext =="png")
&& ($size > 30))
{
$newname=time();
//$ext=end(explode('.',$name));
$fullname=$newname.".".$ext;
$target="uploads/";
$fulltarget=$target.$fullname;
echo $fulltarget;
if(move_uploaded_file($_FILES['img']['tmp_name'],$fulltarget))
{
       $name=$_POST['fnm'];
	   $dt=$_POST['dt'];
	   $phone=$_POST['phone'];
	   $aphone=$_POST['aphone'];
	   $adrs=$_POST['adrs'];
	   $image=$fulltarget;
	   $sql=mysql_query("update `userreg` set `name`='$name',`dob`='$dt',`cnt`='$phone',`acnt`='$aphone',`address`='$adrs',`img`='$image' where `emailid`='$emailid'");
	   if($sql!='')
	   {
		   header('location:userprofile.php');
		   }
		   else
		   {
			   echo 'error';
			   }
}
}
}

		 ?>
		<?php include('footer.php');?>