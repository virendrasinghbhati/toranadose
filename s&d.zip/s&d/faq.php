<?php include('connection.php');?>
<body style="background-color:#CF6;">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="js/jquery-1.11.1.js"/>
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<script src="js/jquery-1.11.1.js" /></script>
<script src="js/bootstrap.min.js"/></script>
<div class="container">
<div class="row">
<div class="col-md-12">
<h2 align="center" style="background-color:#000; color:#FFF; padding-top:10px; padding-bottom:10px;" > "TEARS OF A MOTHER CANNOT SAVE HER CHILD. BUT YOUR BLOOD CAN."</h2>
</div></div>
<div class="row">
<div class="col-md-12 aa">
<div class="nav">
<ul class="nav nav-justified">
<li><a href="home.php"> HOME </a></li>
<li><a href="organisationreg.php">ORG. REGISTRATION</a></li>
<li  class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> PROFILE </a>
<ul class="dropdown-menu">
  <li><a href="orgpro.php">ORGANISATION PROFILE</a></li>
  <li><a href="userprofile.php">USER PROFILE</a></li>
</ul>
</li>
<li><a href="bldcount.php">BLOOD COUNT.</a></li>
<li><a href="orglist.php">ORG. LIST</a></li>
<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> CONTACT US</a>
    <ul class="dropdown-menu">
    <li>Call us-8696238996 </li>
    <li><a href="">virubana9@gmail.com</a></li>
    <li><a href="">erbhati93@gmail.com</a></li>
    </ul> 
</li>

<li  class="dropdown" style="background-color:#000; ">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> LOGIN </a>
  <ul class="dropdown-menu">
  <li><a href="organisationlogin.php">ORGANISATION LOGIN</a></li>
  <li><a href="userlogin.php">USER LOGIN</a></li>
  </ul>
</li>
</ul>
</div>
</div>
</div>
<div class="row">
<div class="col-md-3"></div>
<div class="col-md-6">
<fieldset>
<form action="" method="post" class="" enctype="multipart/form-data"/>
 
<label for="que">QUESTION :</label>
<textarea rows="2" cols="10"  name="ques" placeholder="Please enter your question" class="form-control"></textarea>
<label for="sugg">YOUR SUGGESTION :</label>
<textarea cols="10" rows="2"  name="sugg" placeholder="Please enter your any suggestion" class="form-control"></textarea>
<label for="feed">FEEDBACK FOR US :</label>
<textarea cols="10" rows="2"  name="feed" placeholder="Please enter feedback for us" class="form-control"></textarea>
 <br><input type="submit" name="add" value="ADD"/></br>
</form></fieldset>

<?php
if(isset($_POST['add']))
{
	$ques=$_POST['ques'];
	$sugg=$_POST['sugg'];
	$feed=$_POST['feed'];
	
	$sql=mysql_query("insert into `faq`(`id`,`question`,`suggestion`,`feedback`)values('null','$ques','$sugg','$feed')");
	if($sql!='')
	   {
		   echo 'successfully added';
		   }
		   else
		   {
			   echo 'error';
			   }
	}
?>

 <div class="row">
   <div class="col-md-12">
   <table width="100%" align="center">
   <tr>
   <th> Question</th>
   <th>Answer</th>
   </tr>
      <?php
          $sql=mysql_query("select * from `faq`");
		  while($row=mysql_fetch_array($sql))
		  {
			 ?>
             <tr>
             <th><?php echo $row['question']; ?></th>
             <td><?php echo $row['Answer']; ?></td>
             </tr>
			  <?php
			  }
	  ?>  
   </div></div>


</div>
<div class="col-md-3"></div>
</div>
</div>
</div></body>