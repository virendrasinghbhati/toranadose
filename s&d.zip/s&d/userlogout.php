<?php session_start();?>
<?php 
if($_SESSION['email']!='')
{
	session_destroy();
	unset($_SESSION['email']);
	header('location:userlogin.php');
	}
	else
	{
		echo 'already exist';
		}
?>