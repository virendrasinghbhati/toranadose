<?php session_start();?>
<?php include('connection.php');?>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<div class="container">
<div class="row">
<h2 align="center" style="background-color:#000; color:#FFF; padding-top:10px; padding-bottom:10px;" > "TEARS OF A MOTHER CANNOT SAVE HER CHILD. BUT YOUR BLOOD CAN."</h2>
</div>
<div class="row">
<div class="col-md-12 aa">
<div class="nav">
<ul class="nav nav-justified">
<li><a href="home.php"> HOME </a></li>
<li><a href="organisationreg.php">ORG. REGISTRATION</a></li>
<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> CONTACT US</a>
    <ul class="dropdown-menu">
    <li>Call us-8696238996 </li>
    <li><a href="">virubana9@gmail.com</a></li>
    <li><a href="">erbhati93@gmail.com</a></li>
    </ul>
</li>
</ul></div></div>
</div>
<div class="row">
<div class="col-md-3"></div>
<div class="col-md-6">
<fieldset>
<legend>IF YOU HAVE AN ORGANISATION,PLEASE LOGIN HERE :</legend>
<form action="" method="post" class="">
<label for="">EMAIL ID. :</label>
<input type="text" name="email" class="form-control" placeholder="Please Enter Your Email Id. :"/>
<label for="">PASSWORD :</label>
<input type="password" name="pd" class="form-control" placeholder="Please Enter Your password :"/>
<br><input type="submit" name="login" value="LOGIN"/>
<input type="reset" name="reset" value="RESET"/>
</form>
</fieldset>
<?php
  if(isset($_POST['login']))
  {
	  $aa=$_POST['email'];
	  $bb=$_POST['pd'];
	  if($aa=='' && $bb=='')
	  {
		  echo 'Please Enter Your Email Id And Password';
		  }
		else{  
		  if($aa=='')
		  {
			  echo 'Please Enter Your Emailid';
			  }
			if($bb=='')
			{
		      echo 'Please Enter Your password';		
				}  
	  $sql=mysql_query("select * from `orgreg` where emailid='$aa' and pd='$bb'");
	  $count=mysql_num_rows($sql);
	  if($sql!='')
	  {
		  $_SESSION['emailid']=$aa;
		  $_SESSION['orgid']=$bb;
		  header('location:orgpro.php');
		
		  }
		  else
		  {
			  echo '';
			  }
	  }}
?>

</div>
<div class="col-md-3"></div>
</div>

</div>
<?php include('footer.php');?>