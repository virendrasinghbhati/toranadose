<?php include('connection.php');?>
<?php include('header.php');?>
<div class="row">
<div class="col-md-12">
<table align="center" width="75%" style="background-color:#FC9; margin-top:20px; font-size:28px;">
<tr>
<th>TYPE OF BLOOD</th>
<th>NO. OF UNIT BLOOD</th>
</tr>
<?php 
$sql=mysql_query("select * from `donatestore` ");
while($row=mysql_fetch_array($sql))
{
	?>
       <tr>
       <td><?php echo $row['bldgrp'];?></td>
       <td><?php echo $row['dnttm'];?></td>
       </tr>
	
	<?php }
	?></table>
</div></div></div>
<?php include('footer.php');?>