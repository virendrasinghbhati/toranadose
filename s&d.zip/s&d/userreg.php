<?php session_start(0);?>
<?php include('connection.php');?>
<?php error_reporting(0);?>
<body style="background-color:#999;">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<link rel="stylesheet" type="text/css" href="js/bootstrap.min.js"/>
<script src="js/jquery-1.11.1.js"/></script>
<script src="js/bootstrap.min.js"/></script>
<div class="container">
<div class="row">
<h2 align="center" style="background-color:#000; color:#FFF; padding-top:10px; padding-bottom:10px;" > "TEARS OF A MOTHER CANNOT SAVE HER CHILD. BUT YOUR BLOOD CAN."</h2>
</div>
<div class="row">
<div class="col-md-10 aa">
<div class="nav">
<ul class="nav nav-justified">
<li><a href="home.php"> HOME </a></li>
<li><a href="userprofile.php">USER PROFILE</a></li>
<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> CONTACT US</a>
    <ul class="dropdown-menu">
    <li>Call us-8696238996 </li>
    <li><a href="">virubana9@gmail.com</a></li>
    <li><a href="">erbhati93@gmail.com</a></li>
    </ul>
</li>
</ul></div></div>
<div class="col-md-2">
<div class="nav">
<ul class="nav nav-justified">
<li class="#" style="background-color:#000; padding-bottom:10px; padding-top:10px; font-size:18px;">
<a href="orglogout.php">LOGOUT</a></li>
</li>
</ul>
</div>
</div></div>

<fieldset>
<?php
 if($_SESSION['emailid']!='')
{
       $aa=$_SESSION['emailid'];
	   $sql=mysql_query("select * from `orgreg` where emailid='$aa'");
	   while($row=mysql_fetch_array($sql))
	  {
		?>
		<div class="row">
        <div class="col-md-12">
        <p class="" style="font-size:28px; text-align:center; color:#000; ">
		<?php
		echo 'Welcome:' .$row['orgnm'].'<br>';
		echo 'organisation ID :',$row['id'].'<br>';
		$_SESSION['orgid']=$row['id'];
		$orgid=$row['id'];
		echo 'Please Register A New Donor'.'<br>';
		}
		}
		else
		   {
			echo 'error';
			}
		
?>
</p></div></div>
<div class="row">
<div class="col-md-3"></div>
<div class="col-md-6">
<form action="" method="post" class="" enctype="multipart/form-data" />
 
<label for="">NAME :</label>
<input type="text" name="nm" class="form-control" placeholder="Please Enter Your Full Name"/>
<br><label for="">GENDER :</label>
<input type="radio" name="gender" value="male"/>MALE
<input type="radio" name="gender" value="female"/>FEMALE</br>
<br><label for="">DOB :</label>
<input type="date" name="dt"  /></br>
<br><label for="">BLOOD GROUP :</label>
  <select type="select" name="blood" class="form-control" />
  <option>Your Blood Group is :<option>O+<option>O-<option>A+<option>A-<option>B+<option>B-<option>AB+<option>AB-<option>A1+<option>A1-<option>A2+<option>A2-<option>A1B+<option>A1B-<option>A2B+<option>A2B-</option></select>
  <br><label for="">CONTACT NO. :</label>
  <input type="number" name="contact" class="form-control" placeholder="Please Enter Your Contact No. :"/>
  <br><label for="">ALTERNATE CONTACT NO. :</label>
  <input type="number" name="acontact" class="form-control" placeholder="Please Enter Your Alternate Contact No. :"/>
  <br><label for="">EMAIL ID :</label>
 <input type="text" name="email" class="form-control" placeholder="Please Enter Your Email Id" />
 <br><label for="">PASSWORD :</label>
 <input type="password" name="pd" class="form-control" placeholder="Please Enter Your Password"/>
 <br><label for="">ADDRESS :</label>
 <input type="text" name="adrs" class="form-control" placeholder="Please Enter Your Address"/>
 <br><label for=""> YOUR PICTURE :</label>
 <input type="file" name="img" class="form-control" placeholder="Please Uploade Your Picture"/>
<br> <input type="submit" name="registration" value="REGISTRATION" /></br>
</form></fieldset>
</div>
<div class="col-md-3"></div>
</div>
</div>
</body>

<?php 
  
   if(isset($_POST['registration']))
      {
		  $em=$_POST['emailid'];
		  $sql=mysql_query("select * from `userreg`");
		  while($row=mysql_fetch_array($sql))
		  { 
		  $em1=$row['emailid'];
		  }
		  if($em1!=$em)
		  {
			       $name=$_FILES['img']['name'];
				   $type=$_FILES['img']['type'];
				   $size=($_FILES['img']['size'])/1024;

$ext=end(explode('.',$name));
if (($ext == "gif")
|| ($ext == "jpeg")
|| ($ext == "jpg")
|| ($ext =="png")
&& ($size > 30))
{
$newname=time();
//$ext=end(explode('.',$name));
$fullname=$newname.".".$ext;
$target="uploads/";
$fulltarget=$target.$fullname;
if(move_uploaded_file($_FILES['img']['tmp_name'],$fulltarget))
{
	     
	     $nm=$_POST['nm'];
		 $gender=$_POST['gender'];
		 $dt=$_POST['dt'];
		 $blood=$_POST['blood'];
		 $contact=$_POST['contact'];
		 $acontact=$_POST['acontact'];
         $email=$_POST['email'];
		 $pd=$_POST['pd'];
		 $adrs=$_POST['adrs'];
		 $image=$fulltarget;
		 if($nm=='' || $gender=='' || $dt=='' || $blood=='' || $contact==''|| $acontact=='' || $email=='' || $pd=='' || $adrs=='' || $image=='')
		 {
			 echo 'Please Enter Full description';
			 }
			 else
			 {
				 $sql=mysql_query("insert into `userreg`(`id`,`orid`,`name`,`gen`,`dob`,`bldgrp`,`cnt`,`acnt`,`emailid`,`password`,`address`,`img`) values ('null','$orgid','$nm','$gender','$dt','$blood','$contact','$acontact','$email','$pd','$adrs','$image')");
				 if($sql!='')
				 {
					 echo 'Registration is successfully';
					 }
			  else
			  {
				  echo 'error';
				  }
				 }
			  }}}
		else
		{
			echo 'that email is already exist';
			}	  
		  }
		  

?>

<?php include('footer.php');?>

