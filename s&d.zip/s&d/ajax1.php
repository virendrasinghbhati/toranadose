<?php include('connection.php'); ?>
<?php
     $a=$_POST['cat'];
	
	 $sql=mysql_query("UPDATE `userreg` SET count=count+1 where `emailid`='$a'");
	 // $sql=mysql_query("INSERT INTO `userreg`(`count`)values('$val') where `emailid`='$a'");
	  $sql1=mysql_query("select * from `userreg` where `emailid`='$a' ");
	  while($row=mysql_fetch_array($sql1))
	  {
		  $bdgr =$row['bldgrp'];
	 $sql=mysql_query("UPDATE `donatestore` SET dnttm=dnttm+1 where `bldgrp`='$bdgr'");
	  }
	 ?>
	 