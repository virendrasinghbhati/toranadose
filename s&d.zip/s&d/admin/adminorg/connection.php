<?php
 $host='localhost';
 $username='root';
 $dbname='save';
 $password='';
 $conn=mysql_connect($host,$username,$password) or die (mysql_error());
 mysql_select_db($dbname,$conn) or die (mysql_error());
?>



