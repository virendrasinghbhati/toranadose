<?php include('connection.php');?>
<body style="background-color:#6F0;">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="js/jquery-1.11.1.js"/>
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<script src="js/jquery-1.11.1.js" /></script>
<script src="js/bootstrap.min.js"/></script>
<div class="container">
<div class="row">
<div class="col-md-12">
<h2 align="center" style="background-color:#000; color:#FFF; padding-top:10px; padding-bottom:10px;" > "TEARS OF A MOTHER CANNOT SAVE HER CHILD. BUT YOUR BLOOD CAN."</h2>
</div></div>
<div class="row">
<div class="col-md-12 aa">
<div class="nav">
<ul class="nav nav-justified">
<li><a href="home.php"> HOME </a></li>
<li><a href="organisationreg.php">ORG. REGISTRATION</a></li>
<li  class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> PROFILE </a>
<ul class="dropdown-menu">
  <li><a href="orgpro.php">ORGANISATION PROFILE</a></li>
  <li><a href="userprofile.php">USER PROFILE</a></li>
</ul>
</li>
<li><a href="bldcount.php">BLOOD COUNT.</a></li>
<li><a href="orglist.php">ORG. LIST</a></li>
<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> CONTACT US</a>
    <ul class="dropdown-menu">
    <li>Call us-8696238996 </li>
    <li><a href="">virubana9@gmail.com</a></li>
    <li><a href="">erbhati93@gmail.com</a></li>
    </ul> 
</li>

<li  class="dropdown" style="background-color:#000; ">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> LOGIN </a>
  <ul class="dropdown-menu">
  <li><a href="organisationlogin.php">ORGANISATION LOGIN</a></li>
  <li><a href="userlogin.php">USER LOGIN</a></li>
  </ul>
</li>
</ul>
</div>
</div>
</div>
<div class="row">
<div class="col-md-8">
<p style="padding:20px; margin:10px;">Thiruvananthapuram (Trivandrum): The pictures of Rashtriya Swayamsevak Sangh (RSS) volunteers waiting outside hospital to donate blood for Kollam's Puttingal temple fire victims have gone viral on various social media platforms.

In the pictures, posted on RSS' Facebook page, hundreds of 'swayamsevaks' can be seen waiting outside Trivandrum Medical College to donate blood outside for victims of Puttingal temple fire tragedy.</p>
</div>
<div class="col-md-4">
<img src="picture/1-rss.jpg" width="50%";/>
</div>
</div>
<div class="row">
<div class="col-md-8">
<p style="padding:20px; margin:10px;">Safe blood supplies are still a scarce commodity especially in developing countries despite about 92 million yearly blood donations worldwide! That's why it is imperative to understand the significance of blood donation.

Keeping that in mind, World Blood Donor Day (WBDD) is observed each year globally on 14 June which is an annual celebration meant for expressing gratitude to the blood donors who save lives by donating blood. The day also creates awareness of the need for safe blood for transfusion and to highlight why blood donation is important.</p>
</div>
<div class="col-md-4">
<img src="picture/3.jpg" width="50%";/>
</div>

</div>
<div class="row">
<div class="col-md-8">
<p style="padding:20px; margin:10px;">Blood bank network to be digitised: Govt
Government will explore the possibility of establishing a mechanism where people can check online the availability of required blood groups in blood banks across the country, Health Minister J P Nadda told Lok Sabha on Friday.</p>
</div>
<div class="col-md-4">
<img src="picture/4.jpg" width="50%";/>
</div>
</div>
</div>
</body>
<?php include('footer.php');?>