<?php include('connection.php');?>
<body style="background-color:#0FC;">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="js/jquery-1.11.1.js"/>
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<script src="js/jquery-1.11.1.js"/></script>
<script src="js/bootstrap.min.js"/></script>
<div class="container">
<div class="row">
<div class="col-md-12">
<h2 align="center" style="background-color:#000; color:#FFF; padding-top:10px; padding-bottom:10px;" > "TEARS OF A MOTHER CANNOT SAVE HER CHILD. BUT YOUR BLOOD CAN."</h2>
</div></div>
<div class="row">
<div class="col-md-12 aa">
<div class="nav">
<ul class="nav nav-justified">
<li><a href="home.php"> HOME </a></li>
<li><a href="organisationreg.php">ORG. REGISTRATION</a></li>
<li  class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> PROFILE </a>
<ul class="dropdown-menu">
  <li><a href="orgpro.php">ORGANISATION PROFILE</a></li>
  <li><a href="userprofile.php">USER PROFILE</a></li>
</ul>
</li>
<li><a href="bldcount.php">BLOOD COUNT.</a></li>
<li><a href="orglist.php">ORG. LIST</a></li>
<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> CONTACT US</a>
    <ul class="dropdown-menu">
    <li>Call us-8696238996 </li>
    <li><a href="">virubana9@gmail.com</a></li>
    <li><a href="">erbhati93@gmail.com</a></li>
    </ul> 
</li>

<li  class="dropdown" style="background-color:#000; ">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> LOGIN </a>
  <ul class="dropdown-menu">
  <li><a href="organisationlogin.php">ORGANISATION LOGIN</a></li>
  <li><a href="userlogin.php">USER LOGIN</a></li>
  </ul>
</li>
</ul>
</div>
</div>
</div>
<div class="row">
<div class="col-md-12">
<p style="padding:20px; color:#000;">In patients prone to iron overload, blood donation prevents the accumulation of toxic quantities. Donating blood may reduce the risk of heart disease for men, but the link has not been firmly established and may be from selection bias because donors are screened for health problems.

Research published in 2012 demonstrated that repeated blood donation is effective in reducing blood pressure, blood glucose, HbA1c, low-density lipoprotein/high-density lipoprotein ratio, and heart rate in patients with metabolic syndrome.</p>
</div></div></div></body>
<?php include('footer.php');?>