<div class="container" style="background-color: #1D6161;color: #fff;line-height: 30px;">
<div class="row">
<div class="col-md-12">
<p>&copy; COPYRIGHT2016,ALL RIGHTS RESERVEDS BY:SAVE AND DONATE</p>
</div></div>
</div>