// JavaScript Document
$(document).ready(function(e) {

$('.need').click(function(e){
	e.preventDefault();
var a=$(this).attr('id');
alert(a);
  jQuery.ajax({
			 
			 url: 'ajax2.php',
			  type: 'POST',
			 data: 'cat1='+a,
			  success:function(data)
			  {
				
				  alert('ajax is running');
				  },
				
		  });
	 
	

});    
});
