// JavaScript Document
$(document).ready(function(e) {

$('.donate1').click(function(e){
	e.preventDefault();
var a=$(this).attr('id');
alert(a);
  jQuery.ajax({
			 
			 url: 'ajax1.php',
			  type: 'POST',
			 data: 'cat='+a,
			  success:function(data)
			  {
				
				  alert('ajax is running');
				  },
				
		  });
	 
	

});    
});
