<?php include('connection.php');
include ('header.php');
?>
<div class="row">
<div class="col-md-12">
<ul style="font-size:18px; background-color:#FF9; margin-top:20px; color:#000;">
<li>If you are a blood donor, you are a hero to someone, somewhere, who received your gracious gift of life.
<li>The finest gesture one can make is to save life by donating Blood.
<li>Tears of a mother cannot save her Child. But your Blood can.
<li>The Blood Donor of today may be recipient of tomorrow.
<li>To the young and healthy it is no loss. To sick it is hope of life. Donate Blood to give back life.
<li>The blood is red gold in time of saving a life.
<li>Share a little, care a little = Donate Blood.
<li>Five minutes of your time + 350 ml. of your blood = One life saved.
<li>Blood is meant to circulate. Pass it around.
<li>Donation of Blood means a few minutes to you but a lifetime for somebody else.
<li>Blood is the most precious thing in this world a human being have,If you have some more quotes and slogans on blood     donation Share it with us and others using the comment section below and promote Blood Donation.
</ul>
</div>
</div>
<div class="row zz">
<div class="col-md-6">
<h4>VISION</h4>

India faces a shortage of 4 million blood units in a year. This shortage can be easily eliminated if only an additional 2% of India's youth donated blood, just once in a year. 
Save And Donate Will be launched with the objective of uniting the youth to solve this problem. It acts as ...continue.

</div>
<div class="col-md-3">
<h4>Knowledge Center</h4>
<ul>
<li> <a href="blog.php">Blog</a> 
<li>Videos
<li><a href="news.php">News</a>
<li><a href="faq.php">FAQ's</a>
</ul>
</div>
<div class="col-md-3">
<h4>Please contact us</h4>
<ul>
<li>8696238996
<li>aryacollege.in
<li>www.aryacollege.in
<li>Sp-42,Riico,Kukas,Jaipur
</ul>
</div>
</div>
</div>
</body>
</html>
<?php include('footer.php');?>