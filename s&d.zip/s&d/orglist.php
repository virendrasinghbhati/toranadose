<?php include('connection.php');?>
<?php include('header.php');?>
<div class="container">
 <div class="row">
<div class="col-md-12">
<table align="center" width="40%" style=" margin-top:20px;  background-color:#FCC; ">
<tr>
<th>ID</th>
<th>ORGANISATION NAME</th>
<th>LICENCE NO.</th>
<th>CONTACT NO.</th>

</tr>
<?php 
 $sql=mysql_query(" select * from `orgreg` ");
 while($row=mysql_fetch_array($sql))
 {
	 ?>
     <tr>
     <th><?php echo $row['id'];?></th>
	 <td><?php echo $row['orgnm'];?></td>
     <td><?php echo $row['licenseno'];?></td>
      <td><?php echo $row['contactno'];?></td>
      
     </tr>
	 <?php
	 }
	 ?>
<table>
</div></div></div>
<?php include('footer.php');?>