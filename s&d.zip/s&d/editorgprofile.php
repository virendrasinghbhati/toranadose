<?php session_start();?>
<?php include('connection.php');?>
<?php error_reporting(0);?>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="js/bootstrap.min.js"/>
<script src="js/jquery-1.11.1.js"/></script>
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<div class="container">
<div class="row">
<div class="col-md-12 aa">
<div class="nav">
<ul class="nav nav-justified">
<li><a href="home.php"> HOME </a></li>
<li  class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> PROFILE </a>
<ul class="dropdown-menu">
  <li><a href="orgpro.php">ORGANISATION PROFILE</a></li>
  <li><a href="userprofile.php">USER PROFILE</a></li>
</ul>
</li>
<li><a href="organisationreg.php">ORG. REGISTRATION</a></li>
<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> CONTACT US</a>
    <ul class="dropdown-menu">
    <li>Call us-8696238996 </li>
    <li><a href="">virubana9@gmail.com</a></li>
    <li><a href="">erbhati93@gmail.com</a></li>
    </ul>
</li>
</ul></div></div></div>
<div class="row">
<div class="col-md-12">
<legend>Please Edit Your Profile</legend>
</div></div>
<div class="col-md-3"></div>
<div class="col-md-6">
<fieldset>
<form action="" method="post" enctype="multipart/form-data"/>
<?php 
 
     $emailid=$_SESSION['emailid'];
	 $sql=mysql_query(" select * from `orgreg` where `emailid`='$emailid'");
     while($row=mysql_fetch_array($sql))
	 {
		
	
		 ?>
		 <label for="">ORGANISATION NAME :</label>
         <input type="text" name="organisationnm" value="<?php echo $row['orgnm'];?>" class="form-control"/>
         <label for="">	LICENSE NO. :</label> 
         <input type="text" name="lno" value="<?php echo $row['licenseno'];?>" class="form-control"/>        
         <label for="">CONTACT NO. :</label>
         <input type="number" name="phone" value="<?php echo $row['contactno'];?>" class="form-control"/>
          <label for="">WEBSITE :</label>
         <input type="text" name="website" value="<?php echo $row['site'];?>" class="form-control"/>
          <input type="submit" name="update" value="UPDATE"/>
         </form>
         </fieldset>
		 <?php
		 }
         ?>
         </div> 
         <div class="col-md-3"></div>
         </div>
		 <?php
           if(isset($_POST['update']))
		    {
			  
		   $organisationname=$_POST['organisationnm'];
		   $lno=$_POST['lno'];
		   $phone=$_POST['phone'];
		   $website=$_POST['website'];
	   $sql=mysql_query("update `orgreg` set `orgnm`='$organisationname',`licenseno`='$lno',`contactno`='$phone',`site`='$website' where `emailid`='$emailid'");
	   if($sql!='')
	   {
		   header('location:orgpro.php');
		   }
		   else
		   {
			   echo 'error';
			   }
	}

		 ?>
		 <?php include('footer.php');?>