<?php session_start();?>
<?php
  if($_SESSION['emailid']!='')
  {
	  session_destroy();
	  unset($_SESSION['emailid']);
	  header('location:organisationlogin.php');
	  }
	  else
	  {
		  echo 'Alredy Exist';
		  }

?>

