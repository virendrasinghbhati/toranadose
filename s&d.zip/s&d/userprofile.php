<?php session_start();?>
<?php include('connection.php');?>
<?php error_reporting(0);;?>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<div class="container">
<div class="row">
<h2 align="center" style="background-color:#000; color:#FFF; padding-top:10px; padding-bottom:10px;" > "TEARS OF A MOTHER CANNOT SAVE HER CHILD. BUT YOUR BLOOD CAN."</h2>
</div>
<div class="row">
<div class="col-md-12 aa">
<div class="nav">
<ul class="nav nav-justified">
  <li><a href="home.php"> HOME </a></li>
  <li><a href="edituserprofile.php?emailid=<?php echo $row['id'];?>"> EDIT YOUR PROFILE </a></li>
  <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> CONTACT US</a>
    <ul class="dropdown-menu">
    <li>Call us-8696238996 </li>
    <li><a href="">virubana9@gmail.com</a></li>
    <li><a href="">erbhati93@gmail.com</a></li>
    </ul></li>
  <li> <a href="userlogout.php">LOGOUT</a></li>
                
</ul></div></div></div>
</div>
<?php 
 if($_SESSION['email']!='')
{
       $a=$_SESSION['email'];
	   
	    $sql=mysql_query("select * from `userreg` where emailid='$a'");
	     while($row=mysql_fetch_array($sql))
		 {
			 ?>
			 <div class="container">
             <div class="row">
             <div class="col-md-6">
             <div class= "pro" align="left" style="background-color:#000; color:#FFF; height:300px; padding-left:20px; margin-top:20px; padding-top:20px; font-size:16px;">
			    <ul>
				<?php  	
				echo '1 FULL NAME :'.$row['name'].'<br>';
				echo '2 DATE OF BIRTH :'.$row['dob'].'<br>';
				echo '3 CONTACT NO. :'.$row['cnt'].'<br>';
				echo '4 ALTERNATE CONTACT NO. :'.$row['acnt'].'<br>';
		        echo '5 YOUR BLOOD GROUP :'.$row['bldgrp'].'<br>';	
				echo '6 ADDRESS :'.$row['address'].'<br>';	
				echo '7 That Time You Donate Blood :'.$row['count'].'<br>';
                ?>
                </ul>
               
				</div></div>
                <div class="col-md-3">
                <div class="" style="margin-top:20px;">
				<?php
				echo '<img src="'.$row['img'].'" style=width:100%; " /><br>';
				?>
                
				</div></div>
                <div class="col-md-3">
                <h3 style=" background-color:#000; color:#FFF; font-size:24px; padding:20px;">WELCOME : 
				 <?php  echo $row['name'].'<br>'; ?></h3>
               <p style="padding:20px; font-size:16px; color:#FFF; background-color:#000;">
                 We are happy to welcome you.
                 Your blood group is<?php echo $row['bldgrp'].'<br>' ;?> that is very nice blood group.
                 You can save many human life and made a hero for nature. 
                 </p>
                 
                </div>
                </div>
               
				<?php
			 	}
				}
	else
	{
		?>
		<div class="row">
        <div class="col-md-12">
        <p style="font-size:36px;" align="center">
		<?php
		echo 'PLEASE FIRSTLY ' ;
		?>
		<a href="userlogin.php" style="background-color:#000;  color:#FFF;">LOGIN</a>
        </p></div></div>
		<?php
		 
		}
?>
<?php include('footer.php');?>