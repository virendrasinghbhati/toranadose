<?php include('connection.php');?>
<?php error_reporting(0);?>
<?php include('header.php');?>
<div class="row">
<div class="col-md-3"></div>
<div class="col-md-6">
<fieldset>
<legend>IF YOU ARE AN ORGANISATION, PLEASE REGISTER HERE :</legend>
<form action="" method="post" class="" enctype="multipart/form-data">
<label for="">ORGANISATION NAME :</label>
<input type=" text" name="org" class="form-control" placeholder="Please Enter Your Organisation Name">
<label for="">LICENCE NO. :</label>
<input type="text" name="lic" class="form-control" placeholder="Please Enter Your Organisation Licence Name"/>
<label for=""> CONTACT NO. :</label>
<input type="number" name="contact" class="form-control" placeholder="Please Enter Your Contact Name"/>
<label for="">EMAIL ID. :</label>
<input type="text" name="email" class="form-control" placeholder="Please Enter Your Email Id"/>
<label for="">PASSWORD :</label>
<input type="pasword" name="pass" class="form-control" placeholder="Please Enter Your Password"/>
<label for="" >WEBSITE :</label>
<input type="text" name="website" class="form-control" placeholder="Please Enter Your Website"/>
<label for=""> DATE :</label>
<input type="date" name="dt" class="form-control"/>
<br><input type="submit" name="registration" value="REGISTRATION"/></br>
</form>
</fieldset>
<?php
 if (isset($_POST['registration']))
 {
	 $em=$_POST['email'];
	 $sql=mysql_query("select * from `orgreg` where emailid='$em'");
	 while($row=mysql_fetch_array($sql))
	 { $em1=$row['emailid'];}
	   if($em1!=$em)
	   {
	 $org=$_POST['org'];
	 $lic=$_POST['lic'];
	 $contact=$_POST['contact'];
     $emai=$_POST['email'];
	 $pass=$_POST['pass'];
     $website=$_POST['website'];
	 $dt=$_POST['dt'];
	 $sql=mysql_query("insert into `orgreg`(`id`,`orgnm`,`licenseno`,`contactno`,`emailid`,`pd`,`site`,`date`) values('null','$org','$lic','$contact','$emai','$pass','$website','$dt')");
	    if($sql!='')
		{
			echo 'successfully registration';
			}
			else
			{
				echo 'error';
				}
	 }
 
 else
 {
	 }
}

?>
</div>
<div class="col-md-3"></div>
</div>
</div>
<?php include('footer.php');?>