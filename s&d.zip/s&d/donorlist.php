<?php include('connection.php');?>
<?php include('header.php');?>
<script src="js/myjava.js" type="text/javascript"/></script>
<script src="js/myjava2.js" type="text/javascript"/></script>
<div class="row">
<div class="col-md-12">
<table align="center" width="100%" style=" margin-top:20px; background-color:#FCC;">
<tr>
<th>ID</th>
<th>DONOR NAME</th>
<th>EMAIL ID</th>
<th>BLOOD GROUP</th>
<th>YOU WANT</th>
</tr>
<?php 
 $sql=mysql_query(" select * from `userreg` ");
 while($row=mysql_fetch_array($sql))
 {
	 ?>
     <tr>
     <th><?php echo $row['id'];?></th>
	 <td><?php echo $row['name'];?></td>
     <td><?php echo $row['emailid'];?></td>
     <td><?php echo $row['bldgrp']; ?></td>
     <td><form action="" method="post">
     <input class="donate1" type="submit" name="donate" value="DONATE" id="<?php echo $row['emailid'];?>" >|
     <input class="need" type="submit" name="need" value="NEED" id="<?php echo $row['emailid'];?>"
     </form></td>
     </tr>
	 <?php
	 }
	 ?>
<table>
</div></div></div>
<?php include('footer.php');?>