<?php session_start();?>
<?php include('connection.php');?>
<?php error_reporting(0);
$aa=$_SESSION['emailid'];

?>


<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<script src="js/jquery-1.11.1.js"/></script>
<div class="container">
<div class="row">
<h2 align="center" style="background-color:#000; color:#FFF; padding-top:10px; padding-bottom:10px;" > "TEARS OF A MOTHER CANNOT SAVE HER CHILD. BUT YOUR BLOOD CAN."</h2>
</div>

<div class="row">
<div class="col-md-12 aa">
<div class="nav">
<ul class="nav nav-justified">
<li><a href="home.php"> HOME </a></li>
<li><a href="editorgprofile.php?emailid=<?php echo $row['id'];?>"> EDIT PROFILE </a></li>
<li><a href="userreg.php">USER REGISTRATION</a></li>
<li><a href="donorlist.php">DONOR LIST</a>
  <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> CONTACT US</a>
    <ul class="dropdown-menu">
    <li>Call us-8696238996 </li>
    <li><a href="">virubana9@gmail.com</a></li>
    <li><a href="">erbhati93@gmail.com</a></li>
    </ul></li>
<li><a href="orglogout.php">LOGOUT</a></li>
</ul></div></div></div>
</div>
<?php 
 if($_SESSION['emailid']!='')
{
       $aa=$_SESSION['emailid'];
	   
	    $sql=mysql_query("select * from `orgreg` where emailid='$aa'");
	     while($row=mysql_fetch_array($sql))
		 {
			 ?>
			 <div class="container">
             <div class="row">
             <div class="col-md-7">
             <div class= "pro" align="left" style="background-color:#000; color:#FFF; height:300px; padding-left:20px; margin-top:20px; font-size:16px;">
			    <ul>
				<?php  	
				echo '1 ORGANISATION NAME :'.$row['orgnm'].'<br>';
				echo '2 LICENCE NUMBER :'.$row['licenseno'].'<br>';
				echo '3 CONTACT NO. :'.$row['contactno'].'<br>';
				echo '4 WEBSITE :'.$row['site'].'<br>';	
                ?></ul>
               
				</div></div>
                <div class="col-md-5">
                <div class="" style="margin-top:20px;">
                 
                 
                <h3 style="padding:20px; font-size:24px; color:#FFF; background-color:#000; margin-top:20px;"> WELCOME :
				 <?php  echo $row['orgnm'].'<br>'; ?></h3>
                <p style="padding:20px; font-size:16px; color:#FFF; background-color:#000; margin-top:3px;">
                
                
                 We are happy to welcome you.
                 Your Organistaion is very nice working with us.
                 You can save many human life and made a hero for nature. 
                 </p>
                 
                </div>
                </div>
				<?php
			 	}
				}
	else
	{
		?>
		<div class="row">
        <div class="col-md-12">
        <p style="font-size:36px; text-align:center;">
		<?php
		echo 'PLEASE  FIRSTLY ' ;
		?>
		<a href="organisationlogin.php" style="background-color:#000; font-size:36px; color:#FFF;">LOGIN</a>
		</p></div></div>
		<?php
		 
		}
?>
<?php include('footer.php');?>