<?php // HEADER ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>SAVE AND DONATE</title>
</head>
<body style="background-color:#999;">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<link rel="stylesheet" type="text/css" href="js/bootstrap.min.js"/>
<script src="js/jquery-1.11.1.js"/></script>
<script src="js/bootstrap.min.js"/></script>
<div class="container a">
<div class="row" style="margin-bottom:15px;">
<div class="col-md-12">
<div class="col-md-6"><img src="picture/LOGO.png" alt=""/></div>
<div class="col-md-6" style="text-align:right;">
<ul class="tpnav nav nav-justified">
<li><a href="organisationreg.php">Org. Registration</a></li>
<li  class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> PROFILE </a>
<ul class="dropdown-menu">
  <li><a href="orgpro.php">ORGANISATION PROFILE</a></li>
  <li><a href="userprofile.php">USER PROFILE</a></li>
</ul>
</li>
<li  class="dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> LOGIN </a>
  <ul class="dropdown-menu">
  <li><a href="organisationlogin.php">ORGANISATION LOGIN</a></li>
  <li><a href="userlogin.php">USER LOGIN</a></li>
  </ul>
</li>

</ul>
</div>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="nav">
<ul class="nav nav-justified pmnu">
<li><a href="home.php"> HOME </a></li>


<li><a href="bldcount.php">BLOOD Availibality</a></li>
<li><a href="orglist.php">Organisation List</a></li>
<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"> CONTACT US</a>
    <ul class="dropdown-menu">
    <li>Call us-8696238996 </li>
    <li><a href="">virubana9@gmail.com</a></li>
    <li><a href="">erbhati93@gmail.com</a></li>
    </ul> 
</li>

</ul>
</div>
</div>
</div>
<div class="row">
<div class="col-md-12">
<!-- SLIDER--------------------------------------------------->
<div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>

  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="picture/banner1.jpg" alt="Virendra">
    </div>

    <div class="item">
      <img src="picture/banner2.jpg" alt="Virendra">
    </div>

    <div class="item">
      <img src="picture/banner3.jpg" alt="Virendra">
    </div>

  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<!-- SLider END=====================================================-->

</div>
</div>
